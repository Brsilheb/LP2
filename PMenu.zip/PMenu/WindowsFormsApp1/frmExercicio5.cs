﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1 = int.Parse(Numero1.Text);
            int numero2 = int.Parse(Numero2.Text);

            if (numero1 >= numero2)
            {
                MessageBox.Show("O número mínimo deve ser menor do que o número máximo.");
                return;
            }

            Random rnd = new Random();
            int numeroSorteado = rnd.Next(numero1, numero2 + 1);

            MessageBox.Show($"O número sorteado foi: {numeroSorteado}");
        }
    }
}
