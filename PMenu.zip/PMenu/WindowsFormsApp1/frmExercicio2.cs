﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btninsere1_Click(object sender, EventArgs e)
        {
            int metade = txtPalavra2.Text.Length / 2;

            txtPalavra2.Text = txtPalavra2.Text.Substring(0, metade) +
                txtPalavra1.Text + txtPalavra2.Text.Substring(metade, txtPalavra2.Text.Length - metade);

        }

        private void btncomparar_Click(object sender, EventArgs e)
        {

            if (StringComparer(txtPalavra1.Text, txtPalavra2.Text)
                == 0)
                    MessageBox.Show("São Iguais");
            else
                MessageBox.Show("São diferentes");
        }

        private int StringComparer(string text1, string text2)
        {
            throw new NotImplementedException();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblpalavra1_Click(object sender, EventArgs e)
        {

        }

        private void lblpalavra2_Click(object sender, EventArgs e)
        {

        }

        private void btninsere2_Click(object sender, EventArgs e)
        {

        }
    }
}
