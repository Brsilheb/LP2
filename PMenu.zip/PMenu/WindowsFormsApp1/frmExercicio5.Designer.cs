﻿namespace WindowsFormsApp1
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Numero2 = new System.Windows.Forms.TextBox();
            this.Numero1 = new System.Windows.Forms.TextBox();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.btnSortear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Numero2
            // 
            this.Numero2.Location = new System.Drawing.Point(186, 113);
            this.Numero2.Name = "Numero2";
            this.Numero2.Size = new System.Drawing.Size(181, 20);
            this.Numero2.TabIndex = 20;
            // 
            // Numero1
            // 
            this.Numero1.Location = new System.Drawing.Point(186, 56);
            this.Numero1.Name = "Numero1";
            this.Numero1.Size = new System.Drawing.Size(181, 20);
            this.Numero1.TabIndex = 19;
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(104, 120);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(53, 13);
            this.lblpalavra2.TabIndex = 18;
            this.lblpalavra2.Text = "Número 2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblpalavra1.Location = new System.Drawing.Point(104, 59);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(53, 13);
            this.lblpalavra1.TabIndex = 17;
            this.lblpalavra1.Text = "Número 1";
            // 
            // btnSortear
            // 
            this.btnSortear.Location = new System.Drawing.Point(161, 193);
            this.btnSortear.Name = "btnSortear";
            this.btnSortear.Size = new System.Drawing.Size(180, 111);
            this.btnSortear.TabIndex = 21;
            this.btnSortear.Text = "realize um sorteio entre o primeiro e o segundo número. (usando";
            this.btnSortear.UseVisualStyleBackColor = true;
            this.btnSortear.Click += new System.EventHandler(this.btnSortear_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSortear);
            this.Controls.Add(this.Numero2);
            this.Controls.Add(this.Numero1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Numero2;
        private System.Windows.Forms.TextBox Numero1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Button btnSortear;
    }
}