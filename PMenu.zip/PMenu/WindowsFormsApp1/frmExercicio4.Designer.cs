﻿namespace WindowsFormsApp1
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.btnLocalizarEspaco = new System.Windows.Forms.Button();
            this.btnContarNumeros = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(479, 159);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(182, 110);
            this.btnContarLetras.TabIndex = 22;
            this.btnContarLetras.Text = "que mostre quantos caracteres alfabéticos existem dentro desse";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            this.btnContarLetras.Click += new System.EventHandler(this.btnContarLetras_Click);
            // 
            // btnLocalizarEspaco
            // 
            this.btnLocalizarEspaco.Location = new System.Drawing.Point(255, 159);
            this.btnLocalizarEspaco.Name = "btnLocalizarEspaco";
            this.btnLocalizarEspaco.Size = new System.Drawing.Size(203, 111);
            this.btnLocalizarEspaco.TabIndex = 21;
            this.btnLocalizarEspaco.Text = "que localize o primeiro caracter branco e mostre a sua posição (usando";
            this.btnLocalizarEspaco.UseVisualStyleBackColor = true;
            this.btnLocalizarEspaco.Click += new System.EventHandler(this.btnLocalizarEspaco_Click);
            // 
            // btnContarNumeros
            // 
            this.btnContarNumeros.Location = new System.Drawing.Point(41, 159);
            this.btnContarNumeros.Name = "btnContarNumeros";
            this.btnContarNumeros.Size = new System.Drawing.Size(180, 111);
            this.btnContarNumeros.TabIndex = 20;
            this.btnContarNumeros.Text = "que mostre quantos caracteres numéricos existem dentro desse";
            this.btnContarNumeros.UseVisualStyleBackColor = true;
            this.btnContarNumeros.Click += new System.EventHandler(this.btnContarNumeros_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(255, 22);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(271, 109);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnLocalizarEspaco);
            this.Controls.Add(this.btnContarNumeros);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnContarLetras;
        private System.Windows.Forms.Button btnLocalizarEspaco;
        private System.Windows.Forms.Button btnContarNumeros;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}